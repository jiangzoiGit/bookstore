package entity;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class Orderinfo {
	private int id;
	private int userid;
	private Calendar ordertime;
	private double total;
	@SuppressWarnings("rawtypes")
	private Set itemlist = new HashSet();
	
	public Set getItemlist() {
		return itemlist;
	}
	public void setItemlist(Set itemlist) {
		this.itemlist = itemlist;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public Calendar getOrdertime() {
		return ordertime;
	}
	public void setOrdertime(Calendar ordertime) {
		this.ordertime = ordertime;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
 
}
