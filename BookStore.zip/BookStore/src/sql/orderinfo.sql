create table orderinfo(
id int primary key auto_increment,
userid int,
ordertime datetime,
total double
);