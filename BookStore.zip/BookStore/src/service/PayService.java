package service;

import java.util.ArrayList;

import dao.PayDao;

public class PayService {
	private PayDao payDao = new PayDao();
	public boolean pay(ArrayList booklist, String userid){
		try{
			if (payDao.pay(booklist, userid) == false)
				return false;
			return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}

}
