package dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import test.util.HibernateUtil;
import entity.Bookinfo;
import entity.Userinfo;
import entity.Orderinfo;
import entity.OrderinfoItem;

public class PayDao {
	public boolean pay(ArrayList booklist, String userid)
		throws SQLException, ClassNotFoundException{
		
		Session session = null;		
		try{
			session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	        
	        double total = 0;
	        for (Iterator it = booklist.iterator(); it.hasNext();){
	        	Bookinfo book = (Bookinfo)it.next();
	        	total = total + book.getBooknum() * book.getPrice();
	        }
	        
	        Userinfo user = (Userinfo)session.get(Userinfo.class, userid);
	        
	        if (total + 0.001 > user.getBalance()){
	        	System.out.print("[PayDao:]user:" + user.getUsername() 
	        			       + "; balance:" + user.getBalance()
	        			       + "; Total$: " + total + "\n"); 
	        	session.getTransaction().rollback();
        		HibernateUtil.closeSession(session);
        		return false;
	        }
	        
	        user.setBalance(user.getBalance() - total);
	        session.update(user);
	        
	        Orderinfo order = new Orderinfo();
	        order.setUserid(Integer.parseInt(userid));
	        order.setTotal(total);
	        order.setOrdertime(Calendar.getInstance());
	        
	        for (Iterator it = booklist.iterator(); it.hasNext();)
	        {
	        	Bookinfo newBook = (Bookinfo)it.next();
	        	Bookinfo oldBook = (Bookinfo)session.get(Bookinfo.class, newBook.getId());
	        	
	        	OrderinfoItem item = new OrderinfoItem();
		        item.setBookid(Integer.parseInt(newBook.getId()));
		        item.setBooknum(newBook.getBooknum());
		        item.setOrderinfo(order);
		        order.getItemlist().add(item);
		        
	        	
	        	if (oldBook.getBooknum() >= newBook.getBooknum()){
	        		oldBook.setBooknum(oldBook.getBooknum() - newBook.getBooknum());
		        	session.update(oldBook);
	        	}
	        	else{
	        		session.getTransaction().rollback();
	        		HibernateUtil.closeSession(session);
	        		return false;
	        	}
	        }

	        session.save(order);
			session.getTransaction().commit();
			HibernateUtil.closeSession(session);
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally {
			HibernateUtil.closeSession(session);
		}
		
		return false;
		
	}

}
