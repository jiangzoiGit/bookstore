package dao;

import java.util.List;
import org.hibernate.Session;
import test.util.HibernateUtil;
import entity.Userinfo;

public class testUserinfo {
	
	public List<Userinfo> getAllUserinfo(){
		
		List<Userinfo> result=null;
		Session session = null;
		
		try{
			session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	        
	        result = session.createQuery("from Userinfo").list();
	        
			session.getTransaction().commit();
			
			HibernateUtil.closeSession(session);
		}catch(Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}finally {
			HibernateUtil.closeSession(session);
		}
		return result;
	}

}
