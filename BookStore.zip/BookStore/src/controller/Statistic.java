package controller;

import com.opensymphony.xwork2.ActionSupport;

public class Statistic extends ActionSupport{
	private static final long serialVersionUID = 1L;

	public String execute(){
		return SUCCESS;
	}

}
