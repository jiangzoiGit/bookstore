package controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import entity.Bookinfo;

public class UpdateBookItem extends ActionSupport{
	private ArrayList itemList = null;
	private Bookinfo newBook;
	
	public boolean updateBookItemById(Bookinfo newBook){
		
		System.out.print("UpdateBook: [bookid]=" + newBook.getId() 
						 + " [booknum]=" + newBook.getBooknum() + "\n");
		
		
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		
		itemList = (ArrayList)session.get("cartContent");
		if (itemList != null){
			for (Iterator it = itemList.iterator(); it.hasNext();){
				//check if this book item is existed in Cart
				Bookinfo book = (Bookinfo)it.next();
				if (book.getId().equals(newBook.getId())){
					book.setBooknum(newBook.getBooknum());
					break;
				}
			}
		}
		else{
			itemList = new ArrayList();
		}
		
		session.put("cartContent", itemList);
		return true;
	}
	
	public String execute(){
		if (updateBookItemById(newBook) == false)
			return "fail";
		return "success";
	}

	public Bookinfo getNewBook() {
		return newBook;
	}

	public void setNewBook(Bookinfo newBook) {
		this.newBook = newBook;
	}
}
