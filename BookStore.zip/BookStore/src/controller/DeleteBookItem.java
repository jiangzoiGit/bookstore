package controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import entity.Bookinfo;

public class DeleteBookItem extends ActionSupport{
	private ArrayList itemList = null;
	private Bookinfo newBook;
	
	public boolean deleteBookItemById(Bookinfo newBook){
		
		System.out.print("DeleteBook: [bookid]=" + newBook.getId() + "\n");
		
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		
		itemList = (ArrayList)session.get("cartContent");
		
		if (itemList != null){
			for (Iterator it = itemList.iterator(); it.hasNext();){
				Bookinfo book = (Bookinfo)it.next();
				if (book.getId().equals(newBook.getId())){
					it.remove();
					break;
				}
			}
		}
		else{
			itemList = new ArrayList();
		}
		
		session.put("cartContent", itemList);
		return true;
	}
	
	public String execute(){
		if (deleteBookItemById(newBook) == false)
			return "fail";
		return "success";
	}

	public Bookinfo getNewBook() {
		return newBook;
	}

	public void setNewBook(Bookinfo newBook) {
		this.newBook = newBook;
	}
}
